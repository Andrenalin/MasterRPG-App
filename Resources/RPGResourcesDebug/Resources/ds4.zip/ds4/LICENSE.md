<!--
SPDX-FileCopyrightText: 2022 Johannes Loher

SPDX-License-Identifier: MIT
-->

# Licensing

This project is being developed under the terms of the
[LIMITED LICENSE AGREEMENT FOR MODULE DEVELOPMENT] for Foundry Virtual Tabletop.

The project itself is licensed under multiple licenses. [REUSE] is used to
specify the licenses for the individual files. Most of the licenses are
specified either inside the source file or by an accompanying `.license` file,
but for some files, the licenses are specified in [.reuse/dep5]. Some of the
work that is being reused by this project requires attribution to the original
author(s). You can find these attributions in [ATTRIBUTION.md](ATTRIBUTION.md).

[LIMITED LICENSE AGREEMENT FOR MODULE DEVELOPMENT]: https://foundryvtt.com/article/license/
[REUSE]: https://reuse.software/
[.reuse/dep5]: .reuse/dep5
