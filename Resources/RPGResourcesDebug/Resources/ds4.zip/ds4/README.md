<!--
SPDX-FileCopyrightText: 2021 Johannes Loher
SPDX-FileCopyrightText: 2021 Siegfried Krug

SPDX-License-Identifier: MIT
-->

# DS4

[![status-badge](https://ci.f3l.de/api/badges/5/status.svg)](https://ci.f3l.de/repos/5)
[![REUSE status](https://api.reuse.software/badge/git.f3l.de/dungeonslayers/ds4)](https://api.reuse.software/info/git.f3l.de/dungeonslayers/ds4)
[![Forge installs](https://img.shields.io/badge/dynamic/json?label=Forge%20Installs&query=package.installs&suffix=%25&url=https%3A%2F%2Fforge-vtt.com%2Fapi%2Fbazaar%2Fpackage%2Fds4&colorB=4aa94a)](https://forge-vtt.com/bazaar#package=ds4)
[![Supported foundry versions](https://img.shields.io/endpoint?url=https://foundryshields.com/version?url=https%3A%2F%2Fgit.f3l.de%2Fapi%2Fpackages%2Fdungeonslayers%2Fgeneric%2Fds4%2Flatest%2Fsystem.json)](https://git.f3l.de/dungeonslayers/ds4)
[![Matrix](https://img.shields.io/matrix/ds4%3Aim.f3l.de?server_fqdn=im.f3l.de&logo=matrix&color=0DBD8B)](https://matrix.to/#/#ds4:im.f3l.de)
[![Ko-fi](https://img.shields.io/badge/Ko--fi-ghostfvtt-00B9FE?logo=kofi)](https://ko-fi.com/ghostfvtt)

An implementation of the [Dungeonslayers] 4 game system for [Foundry Virtual
Tabletop].

This system provides sheet support for Actors and Items and mechanical support
for dice and rules necessary to play games of Dungeonslayers 4.

## Installation

To install and use the Dungeonslayers 4 system for Foundry Virtual Tabletop,
find it in the list in the **Install System** dialog on the Setup menu of the
application. Alternatively, paste the following Manifest URL in that dialog:

https://git.f3l.de/api/packages/dungeonslayers/generic/ds4/latest/system.json

## Development

### Prerequisites

In order to build this system, recent versions of `node` and `pnpm` are
required. Most likely using `npm` or `yarn` also works but only `pnpm` is
officially supported. We recommend using the latest lts version of `node`. If
you use `nvm` to manage your `node` versions, you can simply run

```
nvm install
```

in the project's root directory.

You also need to install the project's dependencies. To do so, run

```
pnpm install
```

### Building

You can build the project by running

```
pnpm build
```

Alternatively, you can run

```
pnpm watch
```

to watch for changes and automatically build as necessary.

### Linking the built system to Foundry VTT

In order to provide a fluent development experience, it is recommended to link
the built system to your local Foundry VTT installation's data folder. In order
to do so, first add a file called `foundryconfig.json` to the project root with
the following content:

```
{
    "dataPath": "<path to your home directory>/.local/share/FoundryVTT"
}
```

On platforms other than Linux you need to adjust the path accordingly.

Then run

```
pnpm link-package
```

### Running the tests

You can run the tests with the following command:

```
pnpm test
```

## Contributing

Code and content contributions are accepted. To report issues, please contact us in [Matrix](https://matrix.to/#/#ds4:im.f3l.de).

## Licensing

This project is being developed under the terms of the
[LIMITED LICENSE AGREEMENT FOR MODULE DEVELOPMENT] for Foundry Virtual Tabletop.

The project itself is licensed under multiple licenses. [REUSE] is used to
specify the licenses for the individual files. Most of the licenses are
specified either inside the source file or by an accompanying `.license` file,
but for some files, the licenses are specified in [.reuse/dep5]. Some of the
work that is being reused by this project requires attribution to the original
author(s). You can find these attributions in [ATTRIBUTION.md](ATTRIBUTION.md).

[Dungeonslayers]: https://www.dungeonslayers.net/
[Foundry Virtual Tabletop]: http://foundryvtt.com/
[LIMITED LICENSE AGREEMENT FOR MODULE DEVELOPMENT]: https://foundryvtt.com/article/license/
[REUSE]: https://reuse.software/
[.reuse/dep5]: .reuse/dep5
