<!--
SPDX-FileCopyrightText: 2022 Johannes Loher

SPDX-License-Identifier: MIT
-->

# Attribution

* [Dungeonslayers] by Christian Kennig is licensed under [CC BY-NC-SA 3.0 DE].
* The icons in [assets/icons/official] are derivative work of icons from
  [Dungeonslayers] by Christian Kennig, used under [CC BY-NC-SA 3.0 DE]. They are
  licensed under [CC BY-NC-SA 4.0].
* The compendium packs in [packs] are derivative work of [Dungeonslayers]
  by Christian Kennig, used under [CC BY-NC-SA 3.0 DE]. They are licensed under
  [CC BY-NC-SA 4.0].
* The icons in [assets/icons/game-icons/acro-asercion] by Caro Asercion from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The icons in [assets/icons/game-icons/cathelineau] by Cathelineau from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The icons in [assets/icons/game-icons/darkzaitev] by [DarkZaitzev] from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The icons in [assets/icons/game-icons/delapouite] by [Delapouite] from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The icons in [assets/icons/game-icons/heavenly-dog] by [HeavenlyDog] from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The icons in [assets/icons/game-icons/lorc] by [Lorc] from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The icons in [assets/icons/game-icons/sbed] by [Sbed] from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The icons in [assets/icons/game-icons/skoll] by Skoll from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The icons in [assets/icons/game-icons/willdabeast] by [Willdabeast] from
  [Game-icons.net] are licensed under [CC BY 3.0].
* The images in [assets/tokens/devin-night] by [Devin Night] are
  licensed under these custom [Token Usage Rights].
* The [Lora] font in [fonts/Lora] by The Lora Project Authors is licensed
  under [OFL 1.1].
* The Woodstamp font in [fonts/Woodstamp] by [Ryoichi Tsunekawa] is licensed
  under a custom [EULA](LICENSES/LicenseRef-Woodstamp.txt).

[Dungeonslayers]: https://www.dungeonslayers.net/
[Game-icons.net]: https://game-icons.net/
[DarkZaitzev]: http://darkzaitzev.deviantart.com/
[Delapouite]: https://delapouite.com/
[HeavenlyDog]: http://www.gnomosygoblins.blogspot.com/
[Lorc]: http://lorcblog.blogspot.com/
[Sbed]: http://opengameart.org/content/95-game-icons
[Willdabeast]: http://wjbstories.blogspot.com/
[Devin Night]: https://immortalnights.com/
[Lora]: https://github.com/cyrealtype/Lora-Cyrillic
[Ryoichi Tsunekawa]: https://dharmatype.com/

[CC BY-NC-SA 3.0 DE]: https://creativecommons.org/licenses/by-nc-sa/3.0/de/legalcode
[CC BY-NC-SA 4.0]: LICENSES/CC-BY-NC-SA-4.0.txt
[CC BY 3.0]: LICENSES/CC-BY-3.0.txt
[Token Usage Rights]: LICENSES/LicenseRef-DevinNightTokenUsageRights.txt
[OFL 1.1]: LICENSES/OFL-1.1.txt

[assets/icons/official]: assets/icons/official
[packs]: packs
[assets/icons/game-icons/acro-asercion]: assets/icons/game-icons/acro-asercion/
[assets/icons/game-icons/cathelineau]: assets/icons/game-icons/cathelineau/
[assets/icons/game-icons/darkzaitev]: assets/icons/game-icons/darkzaitev/
[assets/icons/game-icons/delapouite]: assets/icons/game-icons/delapouite/
[assets/icons/game-icons/heavenly-dog]: assets/icons/game-icons/heavenly-dog/
[assets/icons/game-icons/lorc]: assets/icons/game-icons/lorc/
[assets/icons/game-icons/sbed]: assets/icons/game-icons/sbed/
[assets/icons/game-icons/skoll]: assets/icons/game-icons/skoll/
[assets/icons/game-icons/willdabeast]: assets/icons/game-icons/willdabeast/
[assets/tokens/devin-night]: assets/tokens/devin-night
[fonts/Lora]: fonts/Lora/
[fonts/Woodstamp]: fonts/Woodstamp/
